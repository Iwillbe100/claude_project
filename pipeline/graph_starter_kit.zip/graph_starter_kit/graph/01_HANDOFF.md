# 그래프 인계본 — 베트남 5일

**이 파일 하나로 그래프를 설계할 수 있습니다.**
**이것은 강사가 제공하는 예시 인계본입니다.** 루프 킷의 생성기가 뽑은 것을 강의용으로
다듬었습니다. 여러분이 루프 킷을 끝까지 돌리면
`python scripts/export_graph_handoff.py` 가 **여러분의 실측으로 같은 구조의 인계본**을
만들어 줍니다. 이 파일을 손으로 고치지 말고, 바꾸고 싶으면 생성기를 다시 돌리십시오.

> ⚠ 이것은 **예시 인계본**입니다 (강사 제공 베트남 5일 샘플).
> 루프 킷이 **루프 세 개(A 정보량 · B 페이지 · C 정성 완성도)** 로 개정된 뒤의 형식입니다.
> `03_CONTRACT.json` 에 `quality_contract` 가 없으면 개정 전 인계본이니 다시 뽑으세요.
>
> 그래프 쪽은 **루프 골격 + 진단 + 규칙 처방 가지** 구조를 반영했습니다 (3 · 4 · 5 · 6 · 7 · 8 · 9 · 10번).
> 루프 골격(노드 14개)은 그대로 두고, 검사기 바로 뒤에 진단 노드를 세워 **정해진 고칠 법이 있는
> 문제만** 처방 가지로 보냅니다. 나머지는 재수집(LLM)이 맡습니다. 인계본과 킷 문서가 어긋나면
> **그래프 구조는 킷 문서(`CLAUDE.md` · `specs/`)가 정본**입니다.

---

## 1. 목표

```text
베트남 5일 여행 정보 웹페이지 하나(단일 HTML)를 만든다.
도시 3개 · 도시마다 관광지 3곳 · 취향 설명 15줄
일정은 **도시마다 5일** (도시 합계가 아니다) · 하루 4블록 이상 · 시각은 HH:MM
```

> **`days_total` 이 `days_per_city` 로 바뀐 것이 이번 개정의 가장 큰 의미 변화입니다.**
> 이 페이지는 "며칠을 어떻게 돌까"가 아니라 **"어느 도시로 5일을 갈까"** 를 돕습니다.
> 도시들을 합쳐서 세면 한 도시에 몰아 넣은 일정도 통과해 버립니다.

취향 원문은 `02_USER_REQUEST.md` 에 있습니다. **요약본으로는 15줄짜리
취향 설명이 안 나옵니다.** 그 파일을 반드시 같이 넘기세요.

---

## 2. 루프에서 그대로 가져오는 것 (건드리지 마세요)

| 루프의 조건 | 그래프에서 | 어디에 있나 | 이번에 커진 것 |
| --- | --- | --- | --- |
| 관측 표면 (화면 이름표) | **그대로** | `03_CONTRACT.json` 의 `page_contract` | `data-block` 추가 · `data-day` 는 도시 칸 안 |
| 충족 기준 (개수 계약) | **그대로** | `03_CONTRACT.json` 의 `count_contract` | `min_chars` · `dedup` · `asset_rule` · `days_per_city` |
| 판정 독립 (검사기가 밖에) | **그대로** | `scripts/check_*.py` — 루프 킷 파일과 바이트 단위로 같음 | 판정기가 **3개** 로 |
| 종료 선언 (성공 조건) | **그대로** | 아래 6번 | `verify_all` 이 **네 단계**를 본다 |

> 이 넷을 바꾸면 루프판과 그래프판을 **같은 자로 잴 수 없게 됩니다.**
> 실습의 요점이 '같은 계약, 다른 실행 구조'이므로 계약은 고정입니다.

### 계약이 왜 이만큼 넓어졌나 (루프 킷 실측)

한 바퀴를 실제로 돌린 결과물에서 결함 넷이 나왔습니다.
**넷 다 `verify_all.py` 가 `SUCCESS` 를 낸 상태에서 존재했습니다.**

| | 계약이 본 것 | 계약이 못 본 것 | 이번 조치 |
| --- | --- | --- | --- |
| 이미지 | 주소가 **있는가** | 주소가 **살아 있는가** (11장 전부 죽음) | `image.verified` 기록 필수 |
| 취향 설명 | 줄이 **몇 개인가** | 줄이 **서로 다른가** (30줄 중 문형 10종) | 고유 줄 90% · 유사도 60% |
| 상세 | **하한을 넘겼는가** | 하한이 **목표가 되었는가** | 하한을 올리고 "하한은 목표가 아니다"를 명시 |
| 일정 | 칸이 **몇 개인가** | 칸이 **어디에 속하는가** (2+3+2=7) | `days_per_city` · `data-block` |

```text
앞의 셋    전부 코드로 셀 수 있다   ->  계약을 넓혀서 해결
마지막 하나  셀 수 없다             ->  새로운 루프(루프 C)가 필요
```

---

## 3. 노드 — 루프의 작업 8개가 어떻게 옮겨지나

**1:1로 옮기지 않습니다.** **둘**은 노드가 아니게 되고(`일정수집` 은 합쳐지고 `기능점검` 은 간선이 됩니다), **여덟**이 새로 생겨 6 + 8 = 14개가 됩니다.
이 14개가 그래프의 **루프 골격**입니다. 진단 2개와 처방 가지는 이 절 끝에 따로 적었습니다.

| 루프 작업 | 그래프에서 | 종류 | 왜 |
| --- | --- | --- | --- |
| `TASK-입력읽기` | `read_request` | 노드 | 요청서를 읽어 상태의 입력 칸을 채운다 |
| `TASK-국가정보` | `collect_country` | 노드 · **병렬** | 도시와 무관하므로 도시 선정과 나란히 돈다 |
| `TASK-도시선정` | `select_cities` | 노드 | 여기서 도시 수가 정해져야 뒤쪽 병렬 폭이 결정된다 |
| `TASK-명소수집` | `collect_city` | 노드 · **도시별 병렬** | 도시끼리 서로의 결과를 안 보므로 fan-out 가능 |
| `TASK-일정수집` | `collect_city` 에 합침 | — | 같은 도시의 명소만 참조하므로 한 책임으로 묶었다.<br/>다만 **`claude -p` 는 두 번** 부른다 (아래) |
| `TASK-페이지생성` | `build_page` | 노드 | 모든 수집이 끝난 뒤 한 번만 돈다 |
| `TASK-기능점검` | **(간선)** | 노드가 아니다 | `check_page → diagnose_page → build_page` 되돌이 간선(진단 B 뒤 `route_after_page` 의 `retry`)이 이 일을 대신한다 |
| `TASK-정성점검` | `quality_pass` | 노드 · **순차 3회** | 회차 번호가 상태에 있어야 라우터가 셀 수 있다 |

### 루프에는 없던 노드 8개

| 노드 | 루프에서는 | 왜 노드가 되나 |
| --- | --- | --- |
| `check_information` | 검사기 A | **라우터가 읽을 판정 값을 상태에 써야 한다** |
| `check_page` | 검사기 B | 같은 이유 |
| `human_gate_a` | 되물음 ① | `interrupt` 로 멈추고 사람의 답을 상태에 받아 적는다 |
| `human_gate_b` | 되물음 ② | 같은 이유. 선택지가 달라서 노드를 따로 둔다 |
| **`check_quality`** | 검사기 C | **품질이 아니라 절차를 판정해 상태에 쓴다** |
| **`repair_city`** | `RESEARCH` 행동 | **재수집도 fan-out 이다.** 검사기가 지적한 도시만 `Send` 로 받는다 |
| **`rebuilder`** | 없음 | 사람이 게이트에 적은 지시문을 **실제로 소비하는** 자리 |
| **`repair_country`** | `RESEARCH` 행동 | 국가 소개도 **지적된 칸만** patch 로 고친다. 같은 fan-out 을 탄다 |

**`collect_city` 와 `repair_city` 를 왜 나누나.** 하는 일이 다릅니다. 첫 수집은 고른
도시를 **전부** 받고, 재수집은 지적된 도시만 받습니다. 한 노드로 두면 지적이 없는
도시가 들어와도 걸러 낼 데가 없어 **첫 수집으로 떨어집니다** — 멀쩡한 도시를 통째로
다시 뽑느라 부족한 칸이 줄지 않습니다.

**그러면 `collect_country` 로 되돌아가면 되지 않나.** 안 됩니다. 합류 때문입니다.

```text
add_edge(["collect_country", "collect_city"], "check_information")   ← 합류

최소 재현   A ─┐              실측  ['A', 'B', 'J1', 'A']  ← 거기서 끝
            B ─┴→ J ──→ A           예외도 없이 조용히 멈춘다
```

`collect_country` 로만 되돌아가면 합류가 `collect_city` 를 영영 기다립니다.
**재수집이 `repair_*` 라는 별도 노드여야 하는 이유가 이것입니다** — 취향이 아니라
구조 제약입니다.

**`rebuilder` 를 왜 따로 두나.** `build_page` 는 결정론 렌더러라 사람의 지시문을 받을
데가 없습니다. 그리고 `rebuilder` 는 HTML 을 직접 고치지 않고 `research_data.json` 을
고쳐 화면을 다시 만듭니다 — HTML 만 손대면 다음 `build_page` 에서 날아갑니다.

**`collect_city` 는 노드 하나지만 `claude -p` 를 두 번 부릅니다** (명소 / 일정).
노드를 쪼갠 것이 아니라 **한 응답이 감당할 분량**을 나눈 것입니다. 도시 하나가 계약을
채우려면 7,400자인데 이 CLI 의 실측 잘림 임계가 12,341자라 여유가 없습니다.
나누면 3,700자씩이 되고, **일정이 실패해도 명소는 살아남습니다.**

```text
루프에서 검사기는 "돌려 보고 종료 코드를 읽는 것"이었다.
그래프에서 검사기는 "판정 값을 상태에 쓰는 노드"다.

간선이 조건을 보려면 그 값이 상태에 있어야 하기 때문이다.
```

**"작업 8개 → 루프 골격 14개 + 간선 1개"** 입니다. 이 비대칭이 요점입니다.

### 루프 골격 14 + 진단 2 + 규칙 처방 가지 — Studio 그림에는 22개

루프 골격 14개는 **늘지도 줄지도 않습니다.** Studio 그림에는 그 옆에 두 겹이 더 보입니다.

| 겹 | 노드 | 왜 |
| --- | --- | --- |
| 진단 2 | `diagnose_info` (검사기 A 뒤)<br/>`diagnose_page` (검사기 B 뒤) | 검사기는 **판정**(기준을 채웠나)을 쓰고, 진단은 **원인**(무엇이 터졌나)을 쓴다.<br/>원인이 상태에 있어야 라우터가 "정해진 고칠 법이 있는 문제"를 재수집(LLM)보다 먼저 보낼 수 있다 |
| 처방 가지 3 × 2 | `fix_encoding` → `test_encoding`<br/>`fix_image_dead` → `test_image_dead`<br/>`fix_image_spec` → `test_image_spec` | 등록부 `travel_graph/detours/registry.py` **한 줄 = 처방 가지 하나 = 노드 둘.**<br/>진단 노드에서만 갈라지고, 고치고(fix) → 시험 보고(test) → **그 루프의 검사기로 돌아온다** |

```text
루프 골격 14  +  진단 2  +  처방 가지 3 × 2  =  22   (Studio 그림)
```

**왜 검사기가 원인까지 쓰지 않나.** 검사기는 루프 킷과 바이트 단위로 같은 파일이라
고치지 않습니다 (판정 독립). 그리고 처방 가지가 보는 결함 — 깨진 글자, 원본 크기 사진 —
은 **검사기가 세지 않는 종류**라 판정이 PASS 여도 남아 있을 수 있습니다. 그래서 원인은
따로 가립니다. 진단은 그 루프의 **시험지**(`scripts/detour_tests/test_<이름>.py`)를 등록
순서대로 풀어 보고, 불합격인 첫 처방 가지를 고릅니다. 결정론이고, **판정이 PASS 여도 돕니다.**
합격도 같은 시험지로 보므로 "진단은 문제라는데 시험은 합격"인 틈이 구조적으로 없습니다.

킷 기본 셋은 모두 **원인과 고칠 법을 이미 알아본 실패**를 규칙으로 뺀 것입니다. 그래프 안에서
늘 돌고(진단은 매번 · 가지는 그 실패가 났을 때만), 그 실패가 안 나면 진단만 지나갑니다.

| 킷 기본 처방 가지 | 루프 | 시험지가 보는 것 | 어디서 왔나 · 왜 처방 가지인가 |
| --- | --- | --- | --- |
| `encoding` 글자가 깨짐 | A | 모지바케 · 깨진 글자 `�` · 비ASCII 주소 | 알려진 실패 축(Windows cp949 · 현지 글자 파일명) — 로그 전에 미리 구축. 검사기가 세지 않는 결함이라 판정 PASS 여도 있다 |
| `image_dead` 이미지 주소가 죽어 있음 | A | 열었더니 404 · 금지된 주소 형태 · 이미지가 아닌 페이지 | 루프 킷 실행 로그 — `04_RUN_EVIDENCE.md` 1-b (11장 전부 죽음) · 3번 (이미지만 2바퀴 연속). 재수집(LLM)은 주소를 또 지어낸다 |
| `image_spec` 사진이 화면 규격에 안 맞음 | B | `width` 없음(원본 통째) · 사진 틀(CSS) 없음 · 가려짐 | 실습생 게이트 입력 — "이미지 규격이 안 맞음" · 검사기는 사진이 "있는가"만 본다 |

등록 순서가 곧 **진단 우선순위**입니다 (한 루프에서 증상이 둘이면 위의 것부터 하나씩).

**처방 가지는 수집 노드로 돌아가지 않습니다.** 위의 합류 문제 그대로입니다 —
`collect_*` 로 돌아가면 합류가 영영 기다립니다. 그래서 **검사기**로 돌아가고, 거기서
루프 킷과 같은 검사기로 다시 잽니다. 이 복귀 방문은 **바퀴로 세지 않습니다** (6번).

**노드는 처방 가지로만 늘립니다.** 루프 골격이나 진단에는 노드를 더하지 않습니다. 새 처방 가지는
그래프를 돌린 뒤 실패 기록(`python scripts/failure_report.py` 의 ③ · ③-2)에 후보가 있을 때만
**STEP 6** 에서 `python scripts/new_detour.py <이름> --loop A|B --title "…"` 로 세 조각(등록부 한 줄 ·
모듈 · 시험지)을 만들어 붙입니다 — 10번 규칙표 첫 줄입니다. 후보가 없으면 STEP 6 은 하지 않습니다.

---

## 4. 상태 스키마

```python
class TravelState(TypedDict, total=False):
    # 입력 : 노드가 바꾸지 않는다
    country: str
    days: int
    style: dict
    city_priority: list[str]

    # 수집 결과 : 노드가 채운다
    country_intro: dict
    selected_city_names: list[str]
    cities: Annotated[list[dict], merge_cities]           # 병렬이 쓴다 -> reducer 필수
    city_failures: Annotated[list[dict], merge_failures]  # ★ 실패를 숨기지 않는 칸
    #  country_intro 에는 reducer 가 없다 — 재수집 갈래가 **하나뿐**이라
    #  한 걸음에 이 키를 쓰는 노드가 둘 이상이 되지 않는다

    # 판정 : 검사기 노드가 쓰고, 라우터가 읽는다
    info_verdict: str            # UNKNOWN | PASS | SHORT | ERROR
    info_short_slots: list[str]
    page_verdict: str
    page_short_slots: list[str]
    quality_verdict: str
    quality_short_slots: list[str]

    # 산출물
    html_path: str
    research_path: str

    # 제어
    loop_a_iter: int   loop_a_limit: int
    loop_b_iter: int   loop_b_limit: int
    same_error_count: int   same_error_limit: int   last_error_hash: str
    gate_a_answer: str   gate_b_answer: str
    gate_note: str                 # 사람이 적은 자유 문장. 라우팅에 쓰지 않는다
    quality_pass: int              # 0 -> 3.  ★ reducer 금지
    quality_passes_required: int   # 3. 계약에서 온다. 노드가 바꾸지 않는다

    # 진단 · 처방 가지 : 킷 고정 · reducer 없음 (처방 가지는 한 번에 하나만 돈다 → 덮어쓰기)
    inject: list[str]              # 실패 재현 (입력). 평소 []
    failure_kind: str              # "" | 등록된 처방 가지 이름. 진단이 쓰고 ★ 라우터가 읽는 원인 칸
    failure_evidence: list[str]    # "[이름] …" 증상 몇 줄. 게이트 ② 왜 용 — 라우팅에 쓰지 않는다
    detour_attempts: dict          # {처방 가지 이름: 이번에 몇 번 돌았나}. fix 가 올리고 게이트의 more · research · rebuild 가 {} 로
    detour_limit: int              # 2. 처방 한도 — 처방 가지 하나가 사람 없이 돌 수 있는 횟수
    detour_verdict: str            # "" | PASS | FAIL. test 가 쓰고, 검사기 노드가 읽고 비운다

    history: Annotated[list[str], operator.add]
```

> **판정과 원인은 다른 칸입니다.** `info_verdict` · `page_verdict` 는 검사기 노드가 쓰고
> ("기준을 채웠나"), `failure_kind` 는 진단 노드가 씁니다 ("무엇이 터졌나 — 정해진 고칠 법이
> 있나"). 라우터가 둘을 나란히 읽습니다. `failure_evidence` 는 `gate_note` 처럼 사람이 읽는
> 문장이라 **라우팅에 쓰지 않습니다** — 라우터가 보는 원인은 `failure_kind` 하나입니다.
>
> `detour_verdict` 가 `PASS` 인 채로 검사기에 들어온 방문은 **바퀴(`loop_a_iter` ·
> `loop_b_iter`)를 올리지 않고** '같은 오류 반복'도 올리지 않습니다. 처방 가지는 자기 한도
> (처방 한도)를 따로 갖기 때문입니다. 그래서 루프판과의 "반복 횟수" 비교가 그대로 성립합니다.
>
> 상태 칸은 모두 **35개**(29 + 진단 · 처방 가지 6)입니다. Studio 입력 칸은 **5칸**
> (`country` · `days` · `style` · `city_priority` · `inject`)이고, 나머지 초기값은
> `read_request` 가 채웁니다.

> ★ **`quality_pass` 에 `operator.add` 를 붙이지 마십시오.** `cities` 에 reducer 를
> 붙이는 것을 배운 직후라 카운터에도 붙이는 실수가 잦습니다. 회차 번호는 누적
> 리스트가 아니라 **단일 정수 덮어쓰기**입니다. 붙이면 2회차에서 값이 1+2=3 이 되어
> 한 회차를 건너뛰고 나갑니다 (정성이 2회만 돈다). `check_graph_shape.py` 의 **8번 검사**가 잡습니다.

### `city_failures` 의 reducer 는 upsert 로도 부족합니다

빈 껍데기를 정상 결과인 척 돌려주면 게이트(8번)가 아무것도 알리지 못합니다.
그래서 **실패를 담는 칸**을 따로 둡니다. 그런데 이 칸은 `cities` 와 규칙이 다릅니다 —
한 번 실패한 도시가 재수집에 **성공하면 그 줄이 사라져야** 합니다.

```python
def merge_failures(old, new):
    merged = {}
    for row in list(old or []) + list(new or []):
        if row.get("why"):                 # 실패 → 적는다
            merged[row["city"]] = row
        else:                              # 이번엔 성공 → **지운다**
            merged.pop(row["city"], None)
    return list(merged.values())
```

**성공을 "기록이 사라지는 것"으로 표현합니다.** 단순 upsert 면 한 번 터진 도시가
고쳐진 뒤에도 게이트 화면에 실패로 계속 남아 사람이 잘못 판단합니다.

초기값은 `05_STATE_SEED.json` 에 있습니다.

---

## 5. 간선 — 라우터 6개 + fan-out 2개

```text
fan_out_cities       select_cities 뒤       Send × 고른 도시 전부      -> collect_city
                                            (inject 는 첫 도시에만 싣는다)
fan_out_repairs      (아래 둘이 호출)        Send × **지적된 것만**
                                            -> repair_city ×N · repair_country ×0|1

route_after_info     diagnose_info 뒤       처방 가지 이름 -> fix_<이름> (encoding · image_dead)
                                            / SHORT·바퀴 남음 -> Send / 그 밖 -> gate_a
route_after_gate_a   human_gate_a 뒤        more -> Send / proceed -> build / stop -> END
                     ↑ 이 둘이 돌려주는 Send 목록에는 repair_city 와
                       repair_country 가 **섞여** 나간다 (한 걸음에 나란히)
route_after_page     diagnose_page 뒤       처방 가지 이름 -> fix_<이름> (image_spec)
                                            / SHORT -> build_page / 상한 -> gate_b
route_after_gate_b   human_gate_b 뒤        research -> check_information / rebuild -> rebuilder
                                            / quality -> quality_pass / done -> END
route_after_quality  check_quality 뒤       ★ 카운터를 **정상 경로**로 본다
route_after_detour   test_<이름> 뒤          back -> 그 루프의 검사기 / retry -> 같은 fix
                     (처방 가지 셋 공용)      / gate -> 그 루프의 게이트
```

**`route_after_info` · `route_after_page` 는 검사기가 아니라 진단 노드 뒤에 붙습니다.**
검사기 → 진단은 **정적 간선 하나**입니다. 검사기에 조건부 간선까지 달면 두 갈래가
동시에 돕니다 (정적 간선 여러 개는 if/else 가 아니라 병렬).

STEP 3 에서 교육생이 읽고 고칠 수 있는 라우터는 앞의 **넷**(`route_after_info` ·
`route_after_gate_a` · `route_after_page` · `route_after_gate_b`)입니다. 그 안의 처방 가지
분기와 게이트 B 의 정성 분기는 `킷 고정 ▼` 구간이고, `route_after_quality` ·
`route_after_detour` 는 통째로 킷 고정입니다.

**앞의 두 라우터는 문자열 대신 `Send` 목록을 돌려줍니다.** `Send` 는 매핑을 거치지 않고
LangGraph 가 직접 처리합니다. 그래서 `edges.ALLOWED` 표에는 문자열만 적습니다.
처방 가지 이름은 등록부(`travel_graph/detours/registry.py`)에서 읽어 `ALLOWED` 와 `build.py`
의 매핑에 **함께** 들어갑니다 — 한 줄 등록하면 둘이 같이 늘어납니다.

### 원인을 먼저 — 라우터는 두 칸을 나란히 읽는다

```text
판정  info_verdict · page_verdict   검사기 노드가 쓴다   "기준을 채웠나"
원인  failure_kind                  진단 노드가 쓴다     "무엇이 터졌나 — 정해진 고칠 법이 있나"
```

**원인을 먼저, 판정을 다음에, 상한은 탈출구로.** 진단이 처방 가지를 골랐고 그 가지의
처방 한도가 남았으면 **판정이 PASS 여도** 처방 가지로 갑니다. 처방 가지가 보는 결함(깨진 글자 ·
원본 크기 사진)은 검사기가 세지 않기 때문입니다. 원인이 없으면 예전과 똑같이 판정과
상한을 봅니다 — 남은 부족은 재수집(LLM)이 맡습니다.

**게이트 B 의 `research` 는 재수집 노드로 바로 가지 않습니다.** `check_information` 으로
보내 다시 센 뒤 `route_after_info` 가 다친 도시를 고르게 합니다 — "어느 도시를 고칠까"를
정하는 곳을 하나로 둡니다.

### 루프 A·B 의 라우터와 루프 C 의 라우터가 다른 점

```text
route_after_info     (원인 다음) verdict 를 보고, 상한은 **탈출구**로 본다
route_after_page     같음
route_after_quality  카운터를 **정상 경로**로 본다.  <- 상한이 아니라 목표다
route_after_detour   합격(detour_verdict)을 보고, 한도(detour_limit)는 **탈출구**로 본다
```

| | 루프 A·B 의 상한 | 루프 C 의 3회 |
| --- | --- | --- |
| 뜻 | **최대** — 여기까지만 돈다 | **최소이자 최대** — 꼭 3번 돈다 |
| 통과 조건 | 검사기 exit 0 | 3회를 규율대로 기록 |
| 정하는 사람 | 교육생 | **킷 고정** |

**라우터는 작업을 하지 않습니다.** 경로만 고릅니다.

### 실패 라우팅 7종 — 루프에서 그대로 이식

```text
CODE_ERROR               -> RETRY        그 노드만 다시
INFORMATION_INSUFFICIENT -> RESEARCH     부족한 칸만 다시
SPEC_CONFLICT            -> REVISE_SPEC  그래프 밖으로 (사람이 명세를 고침)
TEST_ERROR               -> HITL         human_gate 로
ENVIRONMENT_ERROR        -> HITL
PERMISSION_ERROR         -> HITL
UNKNOWN_ERROR            -> STOP         END 로 직행
```

### 두 축 — `failure_type`(7종) 과 `failure_kind`(처방 가지 이름)

위 7종은 **루프에서 이식한 층**이라 그대로 둡니다. `failure_kind` 는 진단 노드가 쓰는
**더 좁은 분류**이고, 값은 등록된 처방 가지 이름입니다.

| `failure_kind` | 넓게 보면 (`failure_type`) | 왜 재수집(LLM)이 아니라 처방 가지인가 |
| --- | --- | --- |
| `image_dead` | `INFORMATION_INSUFFICIENT` 중 "정보는 있는데 주소가 틀림" | 재수집(LLM)은 같은 식으로 주소를 지어낸다 — 정해진 절차로 고친다 |
| `encoding` | `CODE_ERROR` / `ENVIRONMENT_ERROR` 쪽 (파이프가 글자를 망침) | 검사기가 세지 않는 결함 — 판정 PASS 여도 있다 |
| `image_spec` | `CODE_ERROR` (화면 규격) | 검사기는 사진이 "있는가"만 본다 |

루프에서 문서로만 있던 "실패 라우팅 7종"이 이제 **일부는 실제 배선이 됐습니다.**
원인마다 다른 길이 그림에 보이고(추적), 로그에서 반복된 실패를 같은 모양으로 더할 수 있고(확장),
그 실패를 다시 일으켜 가지가 켜지는지 확인할 수 있습니다(실패 재현 · `inject`) — 루프가
"한 바퀴 더"로 뭉쳐 처리하던 실패 가운데 **원인과 고칠 법을 알아본 것**이 그래프에서는
**규칙 처방 가지**가 됩니다. 나머지는 재수집(LLM)이 맡습니다.

---

## 6. 종료 조건 (그대로)

```text
성공     verify_all.py 가 exit 0 이고, 못 채운 칸이 보고서에 전부 기록되어 있다
         (구조 -> 정보량 -> 페이지 -> 정성, 네 단계 전부)
상한     루프 A 3바퀴 · 루프 B 3바퀴 · 같은 오류 2회   (라우터가 강제)
기록     전체 10회 (D-최대반복) — 그래프는 강제하지 않는다. 바깥 루프는 게이트에서 사람이 소유한다 (travel_graph/contract.py limits())
정성     루프 C **정확히 3회.** 줄이지도 늘리지도 않는다
위 상한(A · B · 같은 오류)에 걸리면 멈추지 않고 human_gate 로 간다
```

### 왜 정성은 "점수"가 아니라 "3회"인가

```text
"품질 8점 이상이면 통과" 로 닫으면?
        ↓
   글을 쓴 쪽이 자기 글에 점수를 준다
        ↓
   판정 독립 붕괴  <-  루프 킷이 경고한 바로 그 실패
```

반복 횟수는 종료 조건이 갖춰야 할 세 성질을 그대로 만족합니다.

```text
관측 가능하다      상태에 정수로 있다
단조 증가한다      줄어들지 않는다
유한 시간에 닿는다  반드시 3에 도달한다
```

그래서 판정기는 **품질을 채점하지 않고 절차를 채점합니다.**

```text
본다        3회를 다 돌았는가
본다        회차마다 규율 10개를 전부 판정했는가
본다        위반이라 적은 것을 실제로 고쳤는가 · 파일 해시가 실제로 바뀌었는가
본다        회차마다 앞 회차의 결과에서 이어지는가        (몰래 고치기 방지)
본다        회차 끝마다 구조·루프 A·B 가 여전히 통과하는가  (되돌아감 방지)
보지 않는다  글이 좋아졌는가
```

### 처방 한도 — 바퀴와 **따로** 센다 (그래프에만 있다)

위의 종료 조건은 루프에서 온 것이라 그대로입니다. 처방 가지는 그래프에만 있는 순환이라
**자기 상한을 따로** 갖습니다 — 바퀴 상한 3 · 처방 한도 2.

```text
처방 한도  처방 가지 하나당 2회 (detour_limit · travel_graph/detours/__init__.py 의 LIMIT)
           합격  -> 그 루프의 검사기로 복귀. 이 방문은 **바퀴로 세지 않는다**
           불합격 · 한도 안 -> 같은 fix 로 한 번 더 (시도할수록 센 방법을 쓴다)
           불합격 · 한도 끝 -> 그 루프의 게이트 (사람)
사람이 more · research · rebuild 를 고르면 처방 가지 횟수가 0 으로 돌아간다
```

> 9번의 "되돌아감의 상한은 `loop_b_iter` 를 그대로 씁니다. 별도 상한을 만들지 마세요"는
> **루프 C 의 되돌아감** 이야기이고 지금도 그대로 참입니다. 처방 가지는 그것과 **다른 순환**
> (진단 → fix → test → 검사기)이라 한도를 따로 둡니다. 바퀴를 처방 가지와 같이 쓰면 가지가
> 한 번 돌 때마다 재수집 기회가 하나씩 사라집니다 — 두 번이면 재수집이 한 번도 못 돕니다.

---

## 7. 병렬 지점

| 나란히 돌 수 있는 것 | 왜 | 주의 |
| --- | --- | --- |
| `collect_country` 와 `select_cities` | 서로의 결과를 안 본다 | 다른 필드에 쓴다 |
| `collect_city` × 3도시 | 도시끼리 독립 | **같은 `cities` 필드 → reducer 필수** |
| `repair_city` × 다친 도시 | 같은 이유 | **같은 reducer 를 지난다. 그래서 멱등이어야 한다** |

> `cities` 에 `operator.add` 를 붙이면 안 됩니다. `repair_city` 가 **같은 도시**를 다시
> 돌려주므로 이어 붙이면 `[하노이, 다낭, 호이안, 하노이, …]` 가 되어 검사기가
> "도시 6개"로 셉니다. 이름을 키로 덮어쓰는 `merge_cities` 가 답입니다.
> **되돌아오는 간선이 있는 그래프에서 reducer 는 멱등해야 합니다.**

**병렬로 못 하는 것**

```text
build_page          모든 수집이 끝나야 한다          (입력이 다 모여야 해서)
select_cities 이전  병렬 폭(도시 수)을 아직 모른다
quality_pass        ★ **자기 앞 회차의 출력이 자기 입력**이라서 (다른 이유다)
처방 가지           ★ **한 번에 하나씩** 순서대로 돈다 (진단이 하나만 고른다)
```

> 정성 회차를 정적 간선 세 개로 늘어놓으면 셋이 같은 파일을 동시에 고칩니다.
> 회차 N 의 `snapshot_before` 는 회차 N-1 의 `snapshot_after` 와 같아야 하고
> 판정기가 그 사슬을 확인하므로, 반드시 **순환 하나로** 세 번 돌립니다.

> **처방 가지는 나란히 돌지 않습니다.** 증상이 둘 이상이면 진단이 등록 순서(= 진단
> 우선순위)대로 **하나만** 고르고, 그 가지가 검사기로 돌아온 뒤 다음 진단에서 다음
> 것을 고릅니다. 처방 가지는 `cities` · `country_intro` 를 통째로 고쳐 돌려주므로 둘이
> 동시에 돌면 `cities` 는 한쪽 수정이 다른 쪽에 덮이고, reducer 가 없는 `country_intro` 는
> 한 걸음에 두 번 쓰여 충돌합니다. 그래서 처방 가지 칸(`failure_kind` ·
> `detour_*`)에는 reducer 가 없습니다 — 한 걸음에 쓰는 노드가 하나뿐입니다.

---

## 8. 사람 개입 — 외부 루프 두 개

| 자리 | 언제 멈추나 | 사람이 고르는 것 |
| --- | --- | --- |
| `human_gate_a` | 루프 A가 끝났을 때 (PASS든 상한이든) **· A 처방 가지가 처방 한도를 다 썼을 때** | 더 모은다 / 이대로 진행 / 멈춘다 |
| `human_gate_b` | 루프 B가 끝났을 때 **· 정성 3회가 끝났을 때 · B 처방 가지가 처방 한도를 다 썼을 때** | 정보 재수집 / 기능 재구축 / 진행·확정 |

**기본 정지는 세 번**(A · B · B 두 번째 = C)입니다. 처방 가지가 처방 한도를 다 쓰면 **그 루프의
게이트**에서 한 번 더 설 수 있습니다 — 처방 가지에는 게이트가 따로 없습니다. 사람이
`more`(A) · `research` · `rebuild`(B) 를 고르면 처방 가지 횟수가 0 으로 돌아갑니다
(`detour_attempts` → `{}` · history 에 `human_gate_a: 처방 한도를 새로 채웁니다` /
`human_gate_b: …`). `proceed` · `stop` · `done` 은 그대로 둡니다. 바깥 루프는
사람 소유라, 사람이 "한 번 더"를 고르면 처방 가지도 다시 설 수 있게 합니다.

**게이트 B는 두 번 섭니다.** 정성 3회 전에는 `done` 이 "정성 점검을 시작한다"는
뜻이고, 3회 뒤에는 "확정하고 끝낸다"는 뜻입니다. 무엇을 묻고 있는지는 게이트
화면 `① 지금` 줄의 `정성 n/3회` 로 구분합니다.

> `research` 나 `rebuild` 를 고르면 결과물이 다시 만들어지므로 정성 회차가 디스크에
> 남긴 수정이 사라지고 해시 사슬도 끊깁니다. 그래서 그때 **회차 카운터가 0으로
> 되돌아갑니다.** 정성은 처음부터 다시입니다.

**세 정지 지점이 같은 5키 화면을 씁니다.** 키 순서가 곧 읽는 순서입니다.

```text
① 지금    한 줄 요약        판정 · 진행 · 부족 개수
② 왜      원인 묶음         목록이 아니라 **요약**이다
③ 권장    상황에서 계산     고정 문구로 두면 틀린 권장을 하게 된다
④ 고르기  선택지            고르면 무슨 일이 일어나는지까지
⑤ 답      입력 형태 그대로  {"action": "...", "note": "..."}
```

`② 왜` 가 핵심입니다. 못 채운 칸 40곳이 실제로는 서너 종류에서 나오므로 목록이 아니라
**요약**을 줍니다. 그리고 원인을 알면 무엇을 지시해야 하는지도 정해지므로,
`⑤ 답` 의 `note` 에 **그대로 붙여 넣을 지시문**을 미리 채워 줍니다.
비워 두면 재수집 프롬프트가 지난 바퀴와 글자 하나 다르지 않습니다.
 수집이 아예 실패한 도시는 여기에 따로 뜹니다 — 부족(`관광지 수 3/0`)과
실패(그 도시를 못 모음)는 판단이 완전히 다르기 때문입니다.

**처방 가지가 못 고친 것은 `② 왜` 의 맨 앞에 뜹니다.** 줄 이름은 `처방 가지가 못 고침 — <제목>`
(예: `처방 가지가 못 고침 — 이미지 주소가 죽어 있음`)이고, 진단 · 시험 노드가
`failure_evidence` 에 남긴 증상 줄과 "고치려면"이 함께 나옵니다. 같은 자리에 두 종류가 더
뜰 수 있습니다 — `처방 가지 시험지가 깨짐 — <제목>`(시험지가 실행 중에 멈춤 · 증상이 아님)과
`처방 가지를 미룸 — <제목> (정성 회차 중)`(정성이 시작된 뒤라 루프 B 처방 가지를 미룸). 정해진 절차로도 안 됐다는
것은 사람이 알아야 하는 사실입니다 — 조용히 넘기면 가장 나쁜 실패입니다.

**권장은 고정 문구가 아니라 상황에서 계산합니다.** 이미지 주소가 죽은 것처럼 **고칠 수 있는** 원인이면 `more` 를 권하고, 인터넷에 없는 정보가 남았거나 바퀴를 다 썼으면 `proceed` 를 권합니다. 고정 `proceed` 로 두었다가 **킷의 버그가 원인인 회차에도 넘어가라고 권한** 실측이 있습니다 — 틀린 권장은 없느니만 못합니다.

> **죽은 이미지 주소는 이제 게이트보다 처방 가지가 먼저 봅니다.** 진단 A 가 `image_dead` 를
> 가려 처방 가지로 보내고, **처방 가지가 못 고친 것만** 게이트에 뜹니다. 그때 게이트 A 의 권장은
> 부족이 남았으면 `more`(재수집이 `note` 대로 다시 찾고, 처방 한도도 새로 채워짐), 검사기가
> 세는 부족이 없으면 `proceed` 입니다. 게이트 B 는 `done` 에 "'고치려면' 칸을 따르십시오" 를
> 붙입니다 — 한 가지의 이유를 다른 가지에 붙이지 않습니다. 처방 가지가 보지 않는 이미지 부족(아직 안
> 모은 칸 등)은 예전처럼 부족 요약으로 뜹니다.

---

## 9. 그래프 모양

```mermaid
flowchart TD
    START([START]) --> N1["read_request"]
    N1 --> N2["collect_country"]
    N1 --> N3["select_cities"]

    subgraph FAN["도시별 병렬 · reducer 필요"]
        direction TB
        S1["collect_city<br/>하노이"]
        S2["collect_city<br/>다낭"]
        S3["collect_city<br/>호이안"]
    end

    N3 -.Send.-> S1
    N3 -.Send.-> S2
    N3 -.Send.-> S3
    S1 --> CI
    S2 --> CI
    S3 --> CI
    N2 --> CI

    CI["check_information<br/>판정을 상태에 쓴다"]
    CI --> DI["◇ diagnose_info<br/>원인을 상태에 쓴다"]
    DI --> RA{"route_after_info"}
    RA -.->|"원인 = encoding · 한도 안"| FXE
    RA -.->|"원인 = image_dead · 한도 안"| FXD
    RA -.->|"SHORT · 3바퀴 미만<br/>Send × 지적된 도시만"| RE["repair_city<br/>patch 로 고친다"]
    RA -.->|"SHORT · 3바퀴 미만<br/>Send × 기능1 부족이면"| RQ["repair_country<br/>patch 로 고친다"]
    RA -->|"PASS · 상한 · ERROR"| HGA
    RE --> CI
    RQ --> CI

    subgraph DTA["▷ 처방 가지 A · 등록부에서 붙는다"]
        direction TB
        FXE["fix_encoding"] --> TXE["test_encoding"]
        FXD["fix_image_dead"] --> TXD["test_image_dead"]
    end
    TXE -->|"back · 합격 · 바퀴 안 씀"| CI
    TXE -.->|"retry · 한도 안"| FXE
    TXE -->|"gate · 한도 끝"| HGA
    TXD -->|"back · 합격 · 바퀴 안 씀"| CI
    TXD -.->|"retry · 한도 안"| FXD
    TXD -->|"gate · 한도 끝"| HGA

    HGA{{"human_gate_a<br/>외부 루프 A · interrupt"}}
    HGA -.->|"more · Send"| RE
    HGA -.->|"more · Send"| RQ
    HGA -->|"proceed · 권장"| BP
    HGA -->|"stop"| STOP([HALT_RESEARCH_GAP])

    BP["build_page<br/>travel_site.html"]
    BP --> CP["check_page<br/>판정을 상태에 쓴다"]
    CP --> DP["◇ diagnose_page<br/>원인을 상태에 쓴다"]
    DP --> RP{"route_after_page"}
    RP -.->|"원인 = image_spec · 한도 안"| FXS
    RP -->|"SHORT · 3바퀴 미만"| BP
    RP -->|"PASS · 상한 · ERROR"| HGB

    subgraph DTB["▷ 처방 가지 B · 등록부에서 붙는다"]
        direction TB
        FXS["fix_image_spec"] --> TXS["test_image_spec"]
    end
    TXS -->|"back · 합격 · 바퀴 안 씀"| CP
    TXS -.->|"retry · 한도 안"| FXS
    TXS -->|"gate · 한도 끝"| HGB

    HGB{{"human_gate_b<br/>외부 루프 B · interrupt<br/>두 번 선다"}}
    HGB -->|"research"| CI
    HGB -->|"rebuild"| RBD["rebuilder<br/>note 에 적은 지시대로 고친다"]
    RBD --> CP
    HGB -->|"done · 정성 3회 미만"| QP
    HGB -->|"done · 정성 3회 완료"| DONE([SUCCESS])

    QP["quality_pass<br/>정성 한 회차 · 순차"]
    QP --> CQ["check_quality<br/>절차를 판정해 상태에 쓴다"]
    CQ --> RC{"route_after_quality"}
    RC -->|"회차 < 3"| QP
    RC -->|"되돌아감"| BP
    RC -->|"3회 완료"| HGB
    RC -->|"판정 불가 · 기록 깨짐"| HALT([HALT_NEEDS_HUMAN])
```

**순환이 넷에서 여섯으로 늘었습니다.** 늘어난 둘이 루프 C입니다 —
`quality_pass ↔ check_quality`(고정 예산) 와 되돌아감 경로
`check_quality → build_page → check_page → human_gate_b → quality_pass`.
되돌아감의 상한은 **`loop_b_iter` 를 그대로 씁니다.** 별도 상한을 만들지 마세요.
(루프 C 되돌아감 이야기입니다. 처방 가지는 다른 순환이라 한도를 따로 둡니다 — 6번.)

**처방 가지가 붙으면서 가지마다 순환이 둘 더 생겼습니다.** 복귀
(`check_* → diagnose_* → fix_<이름> → test_<이름> → check_*`)와 재시도
(`fix_<이름> ↔ test_<이름>`)입니다. 둘 다 `route_after_detour` 가 `detour_limit` 으로 닫습니다.
처방 가지는 **루프 골격의 검사기로** 돌아옵니다 — 수집 노드로 돌아가면 합류가 영영 기다립니다.

> `check_graph_shape.py` 는 이것(루프 골격 · 진단의 순환)을 **10개**로 셉니다. 겹치는 경로(게이트 B를 지나는
> 큰 순환 등)까지 따로 세기 때문입니다. 검사기가 틀린 것이 아니라 세는 단위가 다릅니다.
> 킷 기본 처방 가지 3개가 붙은 지금은 가지를 지나는 겹치는 경로까지 세어 모두 **27개**입니다.
> **개념상 순환은 여섯**입니다 — 안쪽 2 · 바깥 2 · 정성 2. 여기에 **처방 가지마다 복귀 · 재시도 둘**이
> 붙습니다. 종류로 묶으면 **넷**(안쪽 · 바깥 · 정성 · 처방 가지) — 강의 지도의 "순환은 넷"이 이것입니다.

> **정성(루프 C)이 한 회차라도 돈 뒤에는 루프 B 처방 가지를 타지 않습니다.** 정성 3회는 파일
> 해시로 사슬을 잇는데, 그 사이에 처방 가지가 파일을 고치면 사슬이 끊깁니다. 증상은 게이트에
> 남깁니다. 게이트 B 에서 `research` · `rebuild` 를 고르면 정성 회차가 0 이 되므로 다시 탈 수
> 있습니다.

> 그림의 id 는 전부 다르게 둡니다 (`DI` · `DP` · `FXE` · `TXE` …). mermaid 는 같은 id 를
> 한 칸으로 합쳐 버려서, 라우터와 노드가 한 칸이 된 그림이 나옵니다.

---

## 10. 구멍 → 처방 가지로 빼기 고정 규칙

| 실측에서 보이는 구멍 | 그래프에서 하는 일 | 얻는 것 |
| --- | --- | --- |
| 한 노드 안에서 특정 항목만 반복 실패 | 진단 노드 뒤 처방 가지로 뺀다 (STEP 6 · 조건부 · `graph-detour-builder`) | 실패 단위와 재시도 단위를 같게 |
| 매번 노드 전체가 다시 돈다 | 노드 앞에 체크포인트를 둔다 | 채운 칸을 다시 안 모은다 |
| 노드 하나가 유난히 오래 걸린다 | 서로 안 건드리면 병렬로 쪼갠다 | 같은 필드면 reducer |
| 실패는 뒤 노드인데 원인은 앞 노드 | 앞 노드에 출력 검증을 붙인다 | 틀린 값이 안 흘러간다 |
| 사람이 되물음에 매번 같은 답을 한다 | 그 판단을 간선 조건으로 승격한다 | 사람 호출을 줄인다 |
| **셀 수 없는 결함이 남는다** | **고정 예산 순환으로 닫는다** | **판정 독립을 지키며 끝낸다** |
| 검사기가 못 보는 결함 (글자 깨짐 · 사진 규격) | 진단 시험지로 잡는다 (판정이 PASS 여도) | 계약과 검사기를 건드리지 않고 SUCCESS 뒤에 숨은 결함을 드러낸다 |

> **노드는 루프 골격이나 진단에 늘리지 않습니다.** 늘릴 수 있는 곳은 진단 노드 뒤 처방 가지뿐이고,
> 처방 가지는 고치고 → 시험 보고 → **그 루프의 검사기로 돌아옵니다.** 1행과 마지막 행이 그
> 자리입니다. 그래도 **한 번은 일화, 세 번은 패턴**입니다 — STEP 6 은 실패 기록에 후보가 있을 때만
> 하고, 거기서 만든 처방 가지는 본인 킷에만 둡니다. 킷에 넣는 것은 로그에서 반복 확인된 실패
> (여러 교육생 기록에서 3곳 이상) 또는 원인과 고칠 법이 이미 알려진 실패 축(예: 인코딩)입니다.
> (킷 기본 셋 가운데 image_dead 는 두 실행, image_spec 은 게이트 입력 한 번에서 나왔다 — 킷 저자가 보기로 넣은 예외다)

---

## 11. 채점

```bash
python scripts/verify_all.py                  # 구조 -> 정보량 -> 페이지 -> 정성
python scripts/verify_all.py --skip-quality   # 정성 회차 안에서 쓰는 재검증 모드
```

**루프판과 완전히 같은 검사기**입니다. 숫자가 같은 자에서 나왔다는 것이 비교의 근거입니다.
